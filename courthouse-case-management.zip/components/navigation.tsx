"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

export function Navigation() {
  const pathname = usePathname()

  return (
    <nav className="bg-white shadow-lg border-b border-gray-200">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-4">
            <img src="http://googleusercontent.com/file_content/1" alt="Dauphin County Logo" className="h-10 w-auto" />
            <h1 className="text-xl font-bold text-gray-900">Dauphin County Courthouse</h1>
          </div>

          <div className="flex space-x-1">
            <Link
              href="/officer"
              className={cn(
                "px-4 py-2 rounded-lg font-medium transition-all duration-200",
                pathname === "/officer"
                  ? "bg-blue-600 text-white shadow-md"
                  : "text-gray-700 hover:bg-blue-50 hover:text-blue-600",
              )}
            >
              Officer Dashboard
            </Link>
            <Link
              href="/court-staff"
              className={cn(
                "px-4 py-2 rounded-lg font-medium transition-all duration-200",
                pathname === "/court-staff"
                  ? "bg-blue-600 text-white shadow-md"
                  : "text-gray-700 hover:bg-blue-50 hover:text-blue-600",
              )}
            >
              Court Staff Dashboard
            </Link>
          </div>
        </div>
      </div>
    </nav>
  )
}
